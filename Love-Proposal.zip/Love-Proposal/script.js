

// ===== From: script(1).js =====

const intro=document.getElementById("intro");
const countdown=document.getElementById("countdown");

let number=3;

const timer=setInterval(()=>{

number--;

if(number>0){

countdown.innerHTML=number;

}else{

clearInterval(timer);

countdown.innerHTML="❤️";

setTimeout(()=>{

intro.style.opacity="0";

setTimeout(()=>{

intro.remove();

},1000);

},800);

}

},1000);

// ===== From: letterTyping.js =====

const letter=document.getElementById("letter");

const fullText=letter.innerText;

letter.innerText="";

function typeLetter(){

let i=0;

const typing=setInterval(()=>{

letter.innerText+=fullText.charAt(i);

i++;

if(i>=fullText.length){

clearInterval(typing);

}

},35);

}

yesBtn.addEventListener("click",()=>{

setTimeout(typeLetter,1200);

});

// ===== From: effects.js =====

// ===============================
// SUCCESS PAGE ANIMATION
// ===============================

const successCard = document.querySelector(".successCard");

function showSuccessAnimation() {
    successCard.animate([
        { transform: "scale(.6)", opacity: 0 },
        { transform: "scale(1.08)", opacity: 1 },
        { transform: "scale(1)", opacity: 1 }
    ], {
        duration: 800,
        easing: "ease-out"
    });
}

yesBtn.addEventListener("click", showSuccessAnimation);

// ===============================
// HEART BURST
// ===============================

function heartBurst() {
    for(let i=0;i<40;i++){
        const heart=document.createElement("div");
        heart.innerHTML="💖";
        heart.style.position="fixed";
        heart.style.left="50vw";
        heart.style.top="50vh";
        heart.style.fontSize=(16+Math.random()*20)+"px";
        heart.style.pointerEvents="none";
        heart.style.zIndex="99999";
        document.body.appendChild(heart);

        const angle=Math.random()*Math.PI*2;
        const distance=150+Math.random()*250;

        heart.animate([
            {transform:"translate(0,0)",opacity:1},
            {transform:`translate(${Math.cos(angle)*distance}px,${Math.sin(angle)*distance}px)`,opacity:0}
        ],{
            duration:1800,
            easing:"ease-out"
        });

        setTimeout(()=>heart.remove(),1800);
    }
}

yesBtn.addEventListener("click",heartBurst);

// ===============================
// MUSIC VOLUME FADE-IN
// ===============================

music.volume=0;

function fadeMusic(){
    let v=0;
    const fade=setInterval(()=>{
        if(v>=1){
            clearInterval(fade);
        }else{
            v+=0.05;
            music.volume=v;
        }
    },150);
}

yesBtn.addEventListener("click",fadeMusic);

// ===============================
// FINISHED
// ===============================

console.log("❤️ Love Proposal Ready ❤️");

// ===== From: floatingQuotes.js =====

// ===== Floating Love Quotes =====

const quotes = [
"You are my favorite hello ❤️",
"Forever starts with you 💖",
"You make my world brighter ✨",
"Every heartbeat whispers your name ❤️",
"I'll always choose you 💕"
];

function floatingQuote(){

    const text=document.createElement("div");

    text.innerText=quotes[Math.floor(Math.random()*quotes.length)];

    text.style.position="fixed";
    text.style.left=Math.random()*70+10+"vw";
    text.style.bottom="-40px";
    text.style.color="white";
    text.style.fontSize="18px";
    text.style.fontWeight="600";
    text.style.opacity=".9";
    text.style.zIndex="4";

    document.body.appendChild(text);

    text.animate([
        {
            transform:"translateY(0)",
            opacity:0
        },
        {
            transform:"translateY(-350px)",
            opacity:1
        },
        {
            transform:"translateY(-500px)",
            opacity:0
        }
    ],{
        duration:7000
    });

    setTimeout(()=>{
        text.remove();
    },7000);

}

setInterval(floatingQuote,5000);

// ===== From: cursorHearts.js =====

// ===== Romantic Cursor Hearts =====

document.addEventListener("click", function(e){

    const heart = document.createElement("div");

    heart.innerHTML = "💖";

    heart.style.position = "fixed";
    heart.style.left = e.clientX + "px";
    heart.style.top = e.clientY + "px";
    heart.style.fontSize = "26px";
    heart.style.pointerEvents = "none";
    heart.style.zIndex = "99999";

    document.body.appendChild(heart);

    heart.animate([
        {
            transform:"translateY(0) scale(1)",
            opacity:1
        },
        {
            transform:"translateY(-120px) scale(2)",
            opacity:0
        }
    ],{
        duration:1200,
        easing:"ease-out"
    });

    setTimeout(()=>{
        heart.remove();
    },1200);

});