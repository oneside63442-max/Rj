Place your music.mp3 and cat.gif in this folder:
- music.mp3
- cat.gif
